# NewsHub Capstone Project

NewsHub is a Django news application supporting readers, editors,
journalists and publishers. It includes article and newsletter management,
publisher management, subscriptions and a REST API.

## Installation

1. Create and activate a virtual environment:

```text
python -m venv django_env
django_env\Scripts\activate
```

2. Install dependencies:

```text
pip install -r requirements.txt
```

3. Create a MariaDB database:

```sql
CREATE DATABASE news_project CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

4. Configure the database using environment variables if your MariaDB
installation requires a password:

```text
DB_NAME=news_project
DB_USER=root
DB_PASSWORD=your_password
DB_HOST=127.0.0.1
DB_PORT=3306
```

5. Run migrations:

```text
python manage.py migrate
```

6. Create the role groups and permissions:

```text
python manage.py setup_groups
```

Do not run `python manage.py shell` inside `setup_groups.py`. If you want
to inspect the database manually, run that command separately in the
terminal.

7. Create an administrator if required:

```text
python manage.py createsuperuser
```

8. Run the development server:

```text
python manage.py runserver
```

## Main features

- Reader registration and publisher/journalist subscriptions.
- Publisher creation and staff assignment.
- Journalist article and newsletter management.
- Editor approval and full article/newsletter management.
- Publisher listing and detail pages.
- REST API for article retrieval and CRUD operations.
- Automated Django/DRF tests.

## API endpoints

- `GET /api/articles/` — list approved articles.
- `POST /api/articles/` — create an article as an authenticated journalist.
- `GET /api/articles/<id>/` — retrieve an approved article.
- `PUT /api/articles/<id>/` — update an article owned by the journalist.
- `PATCH /api/articles/<id>/` — partially update an owned article.
- `DELETE /api/articles/<id>/` — delete an owned article.

## Tests

Run:

```text
python manage.py test
```

The API tests use Django's testing framework and verify retrieval,
creation, updating, deletion and role-based access control.
